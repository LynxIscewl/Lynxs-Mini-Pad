﻿using StupidTemplate.Categories;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Opens the main settings page for the menu."},
                new ButtonInfo { buttonText = "Movement", method = () => ModCategorys.Movement(), isTogglable = false },
                new ButtonInfo { buttonText = "Visual", method = () => ModCategorys.Visual(), isTogglable = false },
                new ButtonInfo { buttonText = "Rig", method = () => ModCategorys.Rig(), isTogglable = false },
                new ButtonInfo { buttonText = "Fun", method = () => ModCategorys.Fun(), isTogglable = false },
                new ButtonInfo { buttonText = "Safety", method = () => ModCategorys.Safety(), isTogglable = false },
                new ButtonInfo { buttonText = "Room", method = () => ModCategorys.Room(), isTogglable = false },
            },

            new ButtonInfo[] { // Settings
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
            },

            new ButtonInfo[] { // Movement
                new ButtonInfo { buttonText = "Return to Main", method = () => Global.ReturnHome(), isTogglable = true },
                new ButtonInfo { buttonText = "Platforms", method = () => Mods.Platforms(), isTogglable = true },
                


            },

            new ButtonInfo[] { // Visual
                new ButtonInfo { buttonText = "Return to Main", method = () => Global.ReturnHome(), isTogglable = false },
                new ButtonInfo { buttonText = "vis", method = () => Global.ReturnHome(), isTogglable = false },

            },

            new ButtonInfo[] { // Rig
                new ButtonInfo { buttonText = "Return to Main", method = () => Global.ReturnHome(), isTogglable = false },
              new ButtonInfo { buttonText = "rig", method = () => Global.ReturnHome(), isTogglable = false },

            },

            new ButtonInfo[] { // Fun
                new ButtonInfo { buttonText = "Return to Main", method = () => Global.ReturnHome(), isTogglable = false },
               new ButtonInfo { buttonText = "fun", method = () => Global.ReturnHome(), isTogglable = false },

            },

            new ButtonInfo[] { // Safety
                new ButtonInfo { buttonText = "Return to Main", method = () => Global.ReturnHome(), isTogglable = false },
                new ButtonInfo { buttonText = "safe", method = () => Global.ReturnHome(), isTogglable = false },
            },


            new ButtonInfo[] { // Room
            new ButtonInfo { buttonText = "Return to Main", method = () => Global.ReturnHome(), isTogglable = false },
            new ButtonInfo { buttonText = "room", method = () => Global.ReturnHome(), isTogglable = false },


            },

            // leave this here dont delete
              new ButtonInfo[] {
                new ButtonInfo { buttonText = "Disconnect", method = () => Mods.Disconnect(), isTogglable = false },
            },

        };
    }
}
