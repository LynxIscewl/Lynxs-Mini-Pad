﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.iidk.gorillatag.menutemplate";
        public const string Name = "Lynxs Mini Pad";
        public const string Description = "";
        public const string Version = "1.0.0";
    }
}
