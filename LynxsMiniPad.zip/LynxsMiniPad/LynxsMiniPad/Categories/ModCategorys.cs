﻿using static StupidTemplate.Menu.Main;
using static StupidTemplate.Settings;

namespace StupidTemplate.Categories
{
    internal class ModCategorys
    {

        public static void Movement()
        {
            buttonsType = 2;
        }
        public static void Visual()
        {
            buttonsType = 3;
        }
        public static void Rig()
        {
            buttonsType = 4;
        }
        public static void Fun()
        {
            buttonsType = 5;

        }
        public static void Safety()
        {
            buttonsType = 6;
        }

        public static void Room()
        {
            buttonsType = 7;
        }
    }
}
